import { Request, Response } from 'express-serve-static-core';
import ejs from 'ejs';
import { shuttleQRlist } from '../../service/QR/shuttleList';
import { getStudentDAO} from '../../service/user/user'
import { createPDF } from '../../../middleware/createPDF';
export const shuttlePDF = async (req: Request, res: Response) => {
  try {
    const ticket = await shuttleQRlist(req,res);
    const student = await getStudentDAO(req.query.sid);
    ejs.renderFile(
      './src/configs/pdf.ejs',
      {
        name: student?.STUDENT_NAME,
        id: student?.STUDENT_ID,
        grade: student?.STUDENT_SCHYR,
        department: student?.STUDENT_DEPT,
        ticket,
      },
      (err, result) => {
        if (result) {
          createPDF(res, req.query.sid, result);
        } else {
          res.end('An error occurred');
          console.log(err);
        }
      },
    );
  } catch (e) {
    res.status(e.status).json({ message: e.message });
  }
};
