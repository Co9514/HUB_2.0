import express from 'express';
import { shuttlePDF } from '../../service/pdf/PDF';

const router = express.Router();

router.get('/shuttle', shuttlePDF);

export default router;
