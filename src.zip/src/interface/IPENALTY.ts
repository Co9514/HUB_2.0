interface IPENALTY {
  STUDENT_ID: string;
  TICKET_ID: number;
}

export default IPENALTY;
