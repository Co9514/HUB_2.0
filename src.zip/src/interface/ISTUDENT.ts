interface ISTUDENT {
  USER_ID?: string;
  NM?: string;
  DEPT_NM?: string;
  SCHYR?: string;
}

export default ISTUDENT;
